// frontend/game.js

kaboom({
    global: true,
    fullscreen: true,
    clearColor: [0, 0, 0, 1],
  });
  
  // Carregar sprites do trem e trilho
  loadSprite("train", "URL_DA_IMAGEM_DO_TREM.png");
  loadSprite("track", "URL_DA_IMAGEM_DO_TRILHO.png");
  
  // Variáveis globais
  let questionData;
  let currentTime = 20;
  
  // Função para carregar perguntas
  async function fetchQuestion() {
    const res = await fetch("http://localhost:3000/question");
    questionData = await res.json();
    loadQuestion();
  }
  
  // Função para exibir pergunta
  function loadQuestion() {
    add([
      text(questionData.question, { size: 24 }),
      pos(40, 20),
    ]);
  
    questionData.options.forEach((option, index) => {
      add([
        text(option, { size: 16 }),
        pos(40, 80 + index * 50),
        area(),
        "option",
        { correct: option === questionData.correctAnswer },
      ]);
    });
  }
  
  // Evento de clique na resposta
  mouseClick(() => {
    every("option", (choice) => {
      if (isHovered(choice)) {
        if (choice.correct) {
          go("next"); // Avança para próxima pergunta
        } else {
          go("gameover"); // Tela de Game Over
        }
      }
    });
  });
  
  // Cena de Game Over
  scene("gameover", () => {
    add([text("Game Over!", { size: 32 }), pos(width() / 2, height() / 2)]);
  });
  
  // Cena de Próxima Pergunta
  scene("next", () => {
    destroyAll("option");
    fetchQuestion(); // Carrega nova pergunta
  });
  
  // Inicializar o jogo
  fetchQuestion();
  