// backend/app.js

require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const Question = require('./models/Question');

const app = express();
const PORT = 3000;

// Conectar ao MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Conectado ao MongoDB"))
  .catch((error) => console.log("Erro ao conectar ao MongoDB:", error));

// Rota para obter uma pergunta aleatória
app.get('/question', async (req, res) => {
  try {
    const randomQuestion = await Question.aggregate([{ $sample: { size: 1 } }]);
    res.json(randomQuestion[0]);
  } catch (error) {
    res.status(500).json({ message: "Erro ao obter pergunta", error });
  }
});

// Iniciar o servidor
app.listen(PORT, () => console.log(`Servidor rodando em http://localhost:${PORT}`));
